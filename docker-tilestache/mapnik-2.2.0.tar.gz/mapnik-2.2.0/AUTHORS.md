## Mapnik Contributors

Mapnik is written by Artem Pavlenko with contributions from:

* Andy Allen
* AJ Ashton
* Matt Amos
* Lucio Asnaghi
* Justin Bronn
* Christopher Brown
* Jon Burgess
* Toby Collet
* Robert Coup
* Berteun Damman
* Craig de Stigter 
* Jean-Francois Doyon
* David Eastcott
* Krzysztof Godlewski
* Beau Gunderson
* John Hague
* Dominic Hargreaves
* Aubrey Holland
* Tom Hughes
* Konstantin Käfer
* Mak Kolybabi
* Peter Körner
* Hermann Kraus
* Stella Laurenzo
* David Leaver
* Carlos López
* Dennis Luxen
* Tom MacWright
* Michal Migurski
* Andrii Mishkovskyi
* Ben Moores
* Dražen Odobašić
* Cameron Patrick
* Igor Podolskiy
* Reid Priedhorsky
* Brian Quinion
* Marcin Rudowski
* Christopher Schmidt
* Andreas Schneider
* Vincent Schut
* Ehud Shabtai
* David Siegel
* Steve Singer
* Paul Smith
* Vince Spader
* Philipp Spitzer
* Dane Springmeyer
* Dave Stubbs
* River Tarnell
* Oliver Tonnhofer
* Alberto Valverde
* Martijn van Oosterhout 
* Andreas Volz
* Lennard voor den Dag
* Shaun Walbridge
* Rich Wareham
* Nick Whitelegg
* Leslie Wu
